# -*- coding: utf-8 -*-
"""
Created on Wed Nov  2 13:18:16 2022

@author: yashs
"""
import image_slicer
import cv2
import os
img = cv2.imread('static/category/cat/2.jpg', 1)
cv2.imwrite(os.path.join('static/splitimg/image.jpg'),img)
image_slicer.slice('static/splitimg/image.jpg', 25)