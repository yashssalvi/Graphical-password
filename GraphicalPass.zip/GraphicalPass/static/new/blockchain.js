var contract;
ethereum.enable();
var address="0xb8060c12EB4f256B1a90ECDd496Ef387527D4Bf7";
var gasPriceval="3";
var gasval="300";
var globalListBlockchain=[];
$(document).ready(function(){
	
	web3=new Web3(web3.currentProvider);
	//var address="0x64ADd870Fb9d6DbdA79504a7458CaDDF6CfE74da";
	var abi=[
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "string",
					"name": "access",
					"type": "string"
				}
			],
			"name": "checkAccess",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "bool",
					"name": "returnValue",
					"type": "bool"
				}
			],
			"name": "checkRegistry",
			"type": "event"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "string",
					"name": "data",
					"type": "string"
				}
			],
			"name": "getRecord",
			"type": "event"
		},
		{
			"inputs": [
				{
					"internalType": "string",
					"name": "user",
					"type": "string"
				}
			],
			"name": "Login",
			"outputs": [
				{
					"components": [
						{
							"internalType": "address",
							"name": "key",
							"type": "address"
						},
						{
							"internalType": "string",
							"name": "name",
							"type": "string"
						},
						{
							"internalType": "string",
							"name": "dob",
							"type": "string"
						},
						{
							"internalType": "string",
							"name": "mobile",
							"type": "string"
						},
						{
							"internalType": "string",
							"name": "email",
							"type": "string"
						},
						{
							"internalType": "string",
							"name": "password",
							"type": "string"
						}
					],
					"internalType": "struct GraphicalPass.userinfo[]",
					"name": "",
					"type": "tuple[]"
				}
			],
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"inputs": [
				{
					"internalType": "string",
					"name": "user",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "name",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "dob",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "mobile",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "email",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "password",
					"type": "string"
				}
			],
			"name": "userRegister",
			"outputs": [],
			"stateMutability": "nonpayable",
			"type": "function"
		},
		{
			"anonymous": false,
			"inputs": [
				{
					"indexed": false,
					"internalType": "int256",
					"name": "uType",
					"type": "int256"
				}
			],
			"name": "userType",
			"type": "event"
		},
		{
			"inputs": [
				{
					"internalType": "uint256",
					"name": "",
					"type": "uint256"
				}
			],
			"name": "allusers",
			"outputs": [
				{
					"internalType": "address",
					"name": "key",
					"type": "address"
				},
				{
					"internalType": "string",
					"name": "name",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "dob",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "mobile",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "email",
					"type": "string"
				},
				{
					"internalType": "string",
					"name": "password",
					"type": "string"
				}
			],
			"stateMutability": "view",
			"type": "function"
		}
	];
	contract=new web3.eth.Contract(abi,address);
})
