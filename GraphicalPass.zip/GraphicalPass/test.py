import random
import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 
from email.mime.base import MIMEBase 
from email import encoders 

def sendemailtouser(usermail,ogpass):   
    fromaddr = "pranalibscproject@gmail.com"
    toaddr = usermail
    msg = MIMEMultipart()    
    msg['From'] = fromaddr 
    msg['To'] = toaddr 
    msg['Subject'] = "ARBA BUSSNESS.COM"
    body = ogpass
    msg.attach(MIMEText(body, 'plain')) 
    s = smtplib.SMTP('smtp.gmail.com', 587) 
    s.starttls() 
    s.login(fromaddr, "wkwfgosewcljcpqh") 
    text = msg.as_string() 
    s.sendmail(fromaddr, toaddr, text) 
    s.quit()      
    
usermail = "rmundekar2000@gmail.com"
ogpass = "Arba bussness Verify registration successfully . Now you can login."

cmpimgs = "static/images/1.png"
sendemailtouser(usermail,ogpass)    