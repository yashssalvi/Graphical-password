from flask import render_template, Flask, session, request
import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 

from twilio.rest import Client

account_sid = "AC20745de7f90966bd219c430cf160dc15"
auth_token = "9e66ab306749d5dc4baf50f15664c60e"
verify_sid = "VA903e26e0487dced5148de5af857082a7"
# verified_number = "+919930090883"

app = Flask(__name__)

app.secret_key = 'any random string'

UPLOAD_FOLDER = 'static/files/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
        
client = Client(account_sid, auth_token)

def sendemailtouser(usermail,ogpass):   
    fromaddr = "pranalibscproject@gmail.com"
    toaddr = usermail
   
    #instance of MIMEMultipart 
    msg = MIMEMultipart() 
  
    # storing the senders email address   
    msg['From'] = fromaddr 
  
    # storing the receivers email address  
    msg['To'] = toaddr 
  
    # storing the subject  
    msg['Subject'] = "Graphical passoword"
  
    # string to store the body of the mail 
    body = ogpass
  
    # attach the body with the msg instance 
    msg.attach(MIMEText(body, 'plain'))  
  
    # creates SMTP session 
    s = smtplib.SMTP('smtp.gmail.com', 587) 
  
    # start TLS for security 
    s.starttls() 
  
    # Authentication 
    s.login(fromaddr, "wkwfgosewcljcpqh") 
  
    # Converts the Multipart msg into a string 
    text = msg.as_string() 
  
    # sending the mail 
    s.sendmail(fromaddr, toaddr, text) 
  
    # terminating the session 
    s.quit()  

@app.route('/')
def index():
    return render_template("login.html")

@app.route('/ForgetPass')
def ForgetPass():
    return render_template("ForgetPass.html")

@app.route('/logout')
def logout():
    session.pop('name',None)
    return render_template('login.html') 

@app.route('/register',methods=['POST','GET'])
def register():
    return render_template("register.html")

@app.route('/main')
def main():
    return render_template("main.html")  

@app.route('/sendMain',methods=['POST','GET'])
def sendMain():
    if request.method == "POST":
        details = request.form
        name = details['name']
        email = details['email']
        sendemailtouser(email,'Dear '+name+' ! Someone is trying to log in with your account.')
        return "success"
    
@app.route('/sendOTP',methods=['POST','GET'])
def sendOTP():
    if request.method == "POST":
        details = request.form
        name = details['name']
        mobile = details['mobile']
        print('-----------------------------')
        print(name)
        print(mobile)
        print('-----------------------------')

        verification = client.verify.v2.services(verify_sid) \
        .verifications \
        .create(to='+91'+mobile, channel="sms")
        print(verification.status)

        if(verification.status == 'pending'):
            return "success" 
        else:
            return 'fail'
        
@app.route('/sendPass',methods=['POST','GET'])
def sendPass():
    if request.method == "POST":
        details = request.form
        otp = details['otp']
        mail = details['mail']
        password = details['password']
        mobile = details['mobile']
        print('-----------------------------')
        print(otp)
        print(mail)
        print(password)
        print(mobile)
        print('-----------------------------')

        verification_check = client.verify.v2.services(verify_sid) \
        .verification_checks \
        .create(to='+91'+mobile, code=otp)
        print(verification_check.status)

        if(verification_check.status == 'approved'):            
            sendemailtouser(mail,'Your password is : '+ password)
            return "success" 
        else:
            return 'fail'

if __name__ == "__main__":
    # app.run("0.0.0.0")
    app.run(debug=True)
